SARKARI FORM KENDRA — SETUP GUIDE

Files:
- index.html: complete responsive website + Firebase Auth + Firestore admin panel
- firestore.rules: secure Firestore rules (public read, one admin UID can write)

1) Firebase Authentication
- Firebase Console > Authentication > Sign-in method
- Enable Email/Password.
- Authentication > Users > Add user. Create your admin email/password.
- Do NOT add public sign-up to this site.

2) Get Admin UID
- Firebase Console > Authentication > Users
- Open the admin user and copy its User UID.
- Open firestore.rules and replace PASTE_ADMIN_UID_HERE with that UID.
- Firebase Console > Firestore Database > Rules
- Paste the complete firestore.rules content and click Publish.

3) Publish on GitHub Pages
- Create/open your GitHub repository.
- Upload index.html to the repository root (not inside another folder).
- Commit changes.
- Repository Settings > Pages > Deploy from a branch > main > /(root) > Save.
- Wait for GitHub Pages to publish, then open the URL it shows.

4) Important
- Your Firebase web config is included in index.html. A Firebase web API key is not a server secret;
  database protection comes from Authentication and Firestore Security Rules.
- Keep the admin password private. Do not share service-account private keys.
- Use official recruitment links and verify notices before publishing.
- This starter site uses the Firestore collection named "updates".
- If your GitHub Pages site is hosted at a project path, the relative single-file setup still works.
